
/**
 * Write a description of class BMI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class BMI extends JFrame
{
    public BMI(){
        setTitle("BMI Calculator");
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        JLabel heightLabel = new JLabel();
        heightLabel.setText("Height");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        getContentPane().add(heightLabel, gridConstraints);
        
        JLabel weightLabel = new JLabel();
        weightLabel.setText("Weight");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        getContentPane().add(weightLabel, gridConstraints);
        
        JLabel feetLabel = new JLabel();
        feetLabel.setText("Feet");
        gridConstraints.gridx = 4;
        gridConstraints.gridy = 0;
        getContentPane().add(feetLabel, gridConstraints);
        
        JLabel inchLabel = new JLabel();
        inchLabel.setText(" Inches");
        gridConstraints.gridx = 8;
        gridConstraints.gridy = 0;
        getContentPane().add(inchLabel, gridConstraints);

        JLabel bmiLabel = new JLabel();
        bmiLabel.setText("BMI");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        getContentPane().add(bmiLabel, gridConstraints);
        
        JLabel poundLabel = new JLabel();
        poundLabel.setText("Pounds");
        gridConstraints.gridx = 4;
        gridConstraints.gridy = 2;
        getContentPane().add(poundLabel, gridConstraints);
        
        JTextField heightTF = new JTextField();
        heightTF.setText("                                   ");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        getContentPane().add(heightTF, gridConstraints);
        
        JTextField weightTF = new JTextField();
        weightTF.setText("                                   ");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 2;
        getContentPane().add(weightTF, gridConstraints);
        
        JTextField inchTF = new JTextField();
        inchTF.setText("                                   ");
        gridConstraints.gridx = 6;
        gridConstraints.gridy = 0;
        getContentPane().add(inchTF, gridConstraints);
        
        JTextField bmiTF = new JTextField();
        bmiTF.setText("                                   ");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 4;
        getContentPane().add(bmiTF, gridConstraints);
        
        JButton calcButton = new JButton();
        calcButton.setText("Compute BMI");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 6;
        getContentPane().add(calcButton, gridConstraints);
        
        calcButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                double height = Double.parseDouble(heightTF.getText());
                double weight = Double.parseDouble(weightTF.getText());
                double bmi = (weight / (height * height)) *703;
                String bmi2 = Double.toString(bmi);
                bmiTF.setText(bmi2);
            }
        });
        
        JButton convButton = new JButton();
        convButton.setText("Convert");
        gridConstraints.gridx = 8;
        gridConstraints.gridy = 6;
        getContentPane().add(convButton, gridConstraints);
        
        convButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            double inch = Double.parseDouble(inchTF.getText());
            double conv = inch/12;
            String newConv = Double.toString(conv);
            heightTF.setText(newConv);
            }
        });
        
        JButton clearButton = new JButton();
        clearButton.setText("Clear");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 6;
        getContentPane().add(clearButton, gridConstraints);
        
        clearButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                weightTF.setText("                           ");  
                heightTF.setText("                           ");
                bmiTF.setText("                           ");
                inchTF.setText("                                   ");
            }
        });
        
        JButton exitButton = new JButton();
        exitButton.setText("Exit");
        gridConstraints.gridx = 4;
        gridConstraints.gridy = 6;
        getContentPane().add(exitButton, gridConstraints);
        
        exitButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            System.exit(0);
            }
        });

        
        pack();
    }
    public static void main(String[] args){
        new BMI().show();
    }
    
}
